<template>
    <v-container>
        <v-row>
            <v-col class="col-12">
                <GeneralCardComponent>
                    <GeneralCardTitleComponent>Create User</GeneralCardTitleComponent>
                    <v-divider> </v-divider>
                    <v-card-text>
                        <v-row>
                            <v-col class="col-12">
                                <FormsFieldsTextComponent label="Name" v-model="user.name"></FormsFieldsTextComponent>
                            </v-col>
                            <v-col class="col-12">
                                <FormsFieldsTextComponent label="Position" v-model="user.position">
                                </FormsFieldsTextComponent>
                            </v-col>
                            <v-col class="col-12">
                                <FormsFieldsTextComponent label="Email" v-model="user.email">
                                </FormsFieldsTextComponent>
                            </v-col>
                            <v-col class="col-12">
                                <FormsFieldsTextComponent label="Name" v-model="user.phone"></FormsFieldsTextComponent>
                            </v-col>
                            <v-col class="col-12">
                                <FormsFieldsSelectComponent multiple :items="['Electrico','Quimico']" label="Module type" v-model="user.moduleType">
                                </FormsFieldsSelectComponent>
                            </v-col>
                            <v-col class="col-12">
                                <FormsFieldsTextComponent label="Address1" v-model="user.address1">
                                </FormsFieldsTextComponent>
                            </v-col>
                            <v-col class="col-12">
                                <v-row no-gutters>
                                    <v-col class="col-12 col-md-6">
                                        <v-checkbox label="Laboratory director"></v-checkbox>
                                    </v-col>
                                    <v-col class="col-12 col-md-6">
                                        <FormsFieldsSelectComponent :items="comboInfo.listaLaboratory" multiple>
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <v-col class="col-12">
                                <v-row no-gutters>
                                    <v-col class="col-12 col-md-6">
                                        <v-checkbox label="Laboratory technicician"></v-checkbox>
                                    </v-col>
                                    <v-col class="col-12 col-md-6">
                                        <FormsFieldsSelectComponent :items="comboInfo.listaLaboratory" multiple>
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <v-col class="col-12">
                                <v-row no-gutters>
                                    <v-col class="col-12 col-md-6">
                                        <v-checkbox label="Coordinator"></v-checkbox>
                                    </v-col>
                                    <v-col class="col-12 col-md-6">
                                        <FormsFieldsSelectComponent :items="comboInfo.listaLaboratory" multiple>
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <v-col class="col-12">
                                <v-checkbox label="Project leader"></v-checkbox>
                            </v-col>
                            <v-col class="col-12">
                                <v-checkbox label="System Administrator"></v-checkbox>
                            </v-col>
                        </v-row>

                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn class="font-weight-bold black--text rounded-lg" color="yellow" @click="createUser()">
                            Create user</v-btn>
                    </v-card-actions>
                </GeneralCardComponent>
            </v-col>
        </v-row>
        <v-snackbar color="success" v-model="userSnackbar">
            User created successfully
            <v-btn color="white" text @click="userSnackbar=false">
                Close
            </v-btn>
        </v-snackbar>
    </v-container>
</template>


<script>
    import qs from 'qs'
    export default {
        data() {
            return {
                headers: [{
                        text: 'Id',
                        value: 'id'
                    },
                    {
                        text: 'Location',
                        value: 'location'
                    },
                    {
                        text: 'Instruments',
                        value: 'instruments'
                    },
                    {
                        text: 'Capacity',
                        value: 'capacity'
                    },
                    {
                        text: 'Module type',
                        value: 'moduleType'
                    },
                    {
                        text: 'Batteries',
                        value: 'batteries'
                    },
                    {
                        text: 'Batteries Details',
                        value: 'batteriesDetails'
                    },
                    {
                        text: 'Occuped',
                        value: 'occuped'
                    },
                    {
                        text: 'Actions',
                        value: 'actions',
                    },
                ],
                user: {},
                comboInfo: {
                    listaLaboratory: [],
                    listaPlant: [],
                    listaRequestor: [],
                    listaLabTechnician: [],
                    listaStatus: []

                },
                userSnackbar:false,
                listaTipology: ['Circuit', 'Bath', 'Fridge', 'Vibration', 'Warehouse', 'Other']


            }
        },
        created() {
            this.getComboInfo()
        },
        methods: {
            getPromotions() {
                this.items = {}
                this.$axios.get('http://exide.servemp3.com:1337/api/locations/', ).then((response) => {
                    this.items = response.data
                })
            },
            createUser() {
                this.$axios.post('http://exide.servemp3.com:1337/api/users', {
                    data: this.user
                }).then(() => {
                    this.userSnackbar = true
                    setTimeout(() => {
                        this.userSnackbar = false
                    }, 3000)
                    this.$router.push('/security/users')
                })
            },
            getComboInfo() {
                this.items = {}
                this.$axios.get('http://192.168.1.7:45456/Rest/TestRequest/Index', ).then((response) => {

                    let result = {};
                    for (let key in response.data) {
                        if (response.data.hasOwnProperty(key) && typeof response.data[key] === 'object') {
                            result[key] = Object.values(response.data[key]);
                        }
                    }
                    return result
                }).then((data) => {
                    this.comboInfo = data
                })
            },
        }
    }
</script>