<template>
    <v-container>
        <HeadersGeneralComponent>
            <template v-slot:title>
                Analysis Request
            </template>
            <template v-slot:subtitle>
                <v-btn color="yellow" class="rounded-lg font-weight-bold" to="/analysis/create">
                    New<v-icon>mdi-plus</v-icon>
                </v-btn>
            </template>
        </HeadersGeneralComponent>
        <v-row>
            <v-col class="col-12">
                <GeneralCardComponent>
                    <v-card-title dense class="primary" :elevation="0">
                        <v-row>
                            <v-col class="col-md-10 col-12">
                                <v-row>
                                    <v-col>
                                        <FormsFieldsSelectComponent dense label-color="white--text" :items="comboInfo.listaLaboratory" v-model="search.LaboratoryCapacity" label="Laboratory">
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                    <v-col>
                                        <FormsFieldsSelectComponent dense label-color="white--text" :items="comboInfo.listaRequestor"  v-model="search.SelectedRequestor" label="Requestor">
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                    <v-col>
                                        <FormsFieldsSelectComponent dense label-color="white--text"  :items="comboInfo.listaLabTechnician" v-model="search.SelectedLabTechnician" label="Lab technician">
                                        </FormsFieldsSelectComponent>
                                    </v-col>
                                    <v-col>
                                        <FormsFieldsTextComponent type="date" dense  v-model="search.FromDate"  label-color="white--text" label="From">
                                        </FormsFieldsTextComponent>
                                    </v-col>
                                    <v-col>
                                        <FormsFieldsTextComponent type="date" dense v-model="search.ToDate" label-color="white--text" label="to">
                                        </FormsFieldsTextComponent>
                                    </v-col>

                                </v-row>
                            </v-col>
                            <v-col class="col-md-2">
                                <v-btn color="yellow" block class="rounded-lg font-weight-bold mt-7">
                                    Search&nbsp;<v-icon>mdi-magnify</v-icon>
                                </v-btn>
                            </v-col>
                        </v-row>
                    </v-card-title>
                    <v-data-table :headers="headers" @click:row="showRawData($event)" :items="items.data" hide-default-footer class="elevation-1">
                        <template v-slot:item.actions="{ item }">
                            <v-btn-toggle color="primary">
                                <v-btn color="yellow" :to="`/analysis/edit/${item.id}`">
                                    <v-icon>mdi-eye</v-icon>
                                </v-btn>
                            </v-btn-toggle>
                        </template>
                    </v-data-table>
                </GeneralCardComponent>
            </v-col>
        </v-row>
    </v-container>
</template>


<script>
    import qs from 'qs'
    import moment from 'moment'
    import axios from 'axios'
    export default {
        data() {
            return {
                headers: [{
                        text: 'BatchNumber',
                        value: 'id'
                    },
                    {
                        text: 'Code',
                        value: 'code'
                    },
                    {
                        text: 'Description',
                        value: 'subject'
                    },
                    {
                        text: 'FechaCreacion',
                        value: 'createdAt'
                    },
                    {
                        text: 'NombreSolicitante',
                        value: 'applicantName'
                    },
                    {
                        text: 'Status',
                        value: 'status'
                    },
                    {
                        text: 'Final del analisis',
                        value: 'deliveryDate'
                    },
                    {
                        text: 'Laboratorio',
                        value: 'laboratory'
                    },
                    {
                        text: 'Tecnico',
                        value: 'technician'
                    },
                    {
                        text: '% Avance',
                        value: 'progress'
                    },
                    {
                        text: 'Actions',
                        value: 'actions'
                    },
                ],
                    search:{
                        LaboratoryCapacity:'',
                        SelectedRequestor:'',
                        SelectedLabTechnician:'',
                        FromDate:'',
                        ToDate:'',
                    },
                comboInfo:{
                    listaLaboratory:[],
                    listaPlant:[],
                    listaRequestor:[],
                    listaLabTechnician:[]
                },
                items: {
                    data:[]
                },

            }
        },
        created() {
            this.search.FromDate = moment().subtract(2,'years').format('YYYY-MM-DD')
            this.search.ToDate = moment().add(50,'years').format('YYYY-MM-DD')
            this.getComboInfo()
            this.getAnalysis()
        },
        methods: {
            getComboInfo() {
                this.items = {}
                this.$axios.get('http://192.168.1.7:45456/Rest/TestRequest/Index', ).then((response) => {

                    let result = {};
                    for (let key in response.data) {
                    if (response.data.hasOwnProperty(key) && typeof response.data[key] === 'object') {
                        result[key] = Object.values(response.data[key]);
                    }
                    }
                    return result
                }).then((data)=>{
                    this.comboInfo = data
                })
            },
            getAnalysis() {
                this.clients = []
                this.$axios.get('http://exide.servemp3.com:1337/api/analyses/?populate=*', {
                    paramsSerializer: params => {
                        return qs.stringify(params, {
                            arrayFormat: 'brackets'
                        })
                    }

                }).then((response) => {
                    this.items = response.data
                })
            },
            showRawData($e) {
                console.log($e)
            }
        }
    }
</script>